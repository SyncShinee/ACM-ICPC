#include <cstdio>
#include <cstring>
#include <algorithm>
#include <set>
#include <map>
#include <vector>
#include <queue>
#define N 
#define DEBUG 1
using namespace std;
typedef long long ll;
void init() {

}

void stress() {

}

void solve() {

}

int main() {
	init();
	if (DEBUG == 1) {
		stress();
	}
	else {
		solve();
	}
}